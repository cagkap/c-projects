//
// Created by Cagla on 12/11/2020.
//
#include <iostream>
#include <string>
#include <fstream>
#include <array>
using namespace std;
#include "Card.h"
#include "foundationArrays.h"
#include <bits/stdc++.h>
foundationArrays::foundationArrays() {


}
bool foundationArrays::getInfo(string name) {
    int n = name.length();
    char command[n + 1];
    strcpy(command, name.c_str());
    int i;
    string name2 = "";
    for (i = 0; i < 3; i++) {
        name2 = name2 + name[i];
    }

    if (command[0] == 'H') {
        if (hearts[0].getName() == "") {
            if(command[1]=='0'&&command[2]=='1'){
            putCard(hearts, name2);
            return true;
            }else{
                return false;
            }
        }
        int i = int(getLast(hearts)[2]) - 48;
        int j = int(command[2]) - 48;
        if ((command[1] == '0' && getLast(hearts)[1] == '0' && i + 1 == j) ||
            (getLast(hearts)[1] == '1' && i + 1 == j) ||
            (command[1] == '1' && command[2] == '0' && getLast(hearts)[2] == '9')) {
            putCard(hearts, name2);
            return true;

        } else {
            return false;
        }
    } else if (command[0] == 'S') {

        if (spades[0].getName() == "") {
            if(command[1]=='0'&&command[2]=='1'){
            putCard(spades, name2);
            return true;
            }else{
                return false;
            }
        }
        int i = int(getLast(spades)[2]) - 48;
        int j = int(command[2]) - 48;
        if ((command[1] == '0' && getLast(spades)[1] == '0' && i + 1 == j) ||
            (getLast(spades)[1] == '1' && i + 1 == j) ||
            (command[1] == '1' && name[2] == '0' && getLast(spades)[2] == '9')) {
            putCard(spades, name2);
            return true;
        } else {
            return false;
        }
    } else if (command[0] == 'C') {

        if (clubs[0].getName() == "") {
            if(command[1]=='0'&&command[2]=='1') {
                putCard(clubs, name2);
                return true;
            }else{
                return false;
            }
        }
        char *charlist = getLast(clubs);
        int i = int(charlist[2]) - 48;
        int j = int(command[2]) - 48;
        if ((command[1] == '0' && getLast(clubs)[1] == '0' && i + 1 == j) || (getLast(clubs)[1] == '1' && i + 1 == j) ||
            (command[1] == '1' && command[2] == '0' && getLast(clubs)[2] == '9')) {
            putCard(clubs, name2);
            return true;
        } else {
            return false;
        }
    } else if (command[0] == 'D') {

        if (diamonds[0].getName() == "") {
            if(command[1]=='0'&&command[2]=='1') {
                putCard(diamonds, name2);
                return true;
            }else{
                return false;
            }
        }
        int i = int(getLast(diamonds)[2]) - 48;
        int j = int(command[2]) - 48;
        if ((command[1] == '0' && getLast(diamonds)[1] == '0' && i + 1 == j) ||
            (getLast(diamonds)[1] == '1' && i + 1 == j) ||
            (command[1] == '1' && command[2] == '0' && getLast(diamonds)[2] == '9')) {
            putCard(diamonds, name2);
            return true;
        } else {
            return false;
        }

    }

}
void foundationArrays::putCard(array<Card, 13> &array,string name) {
    for(int i=0;i<=12;i++){
        if(array[i].getName()==""){
            array[i].setName(name);
            break;
        }
    }
}
char* foundationArrays::getLast(array<Card, 13> array) {
    for(int i=12;i>=0;i--){
        if(array[i].getName()!=""){
            static char cardName[3];
            strcpy(cardName, array[i].getName().c_str());
            return cardName;
        }
    }
}
void foundationArrays::printFoundation(array<Card, 13> foundation,ofstream &outputText) {
    if (foundation[0].getName() == "") {
        outputText << "___ ";
        cout.flush();
    } else {
        for (int i = 12; i >= 0; i--) {
            if (foundation[i].getName() != "") {
                outputText << foundation[i].getName()<<" ";
                cout.flush();
                break;
            }


        }
    }
}
string foundationArrays::getFromFoundation(char i) {
    if(i=='0'){
        return getCard(hearts);
    }else if(i=='1'){
        return getCard(diamonds);
    }else if(i=='2'){
        return getCard(spades);
    }else if(i=='3'){
        return getCard(clubs);

    }
}
string foundationArrays::getCard(array<Card, 13> &array)  {
    string name;
    for(int i = 12; i >= 0; i--){
        if(array[i].getName()!=""){
            name=array[i].getName();
            array[i].setName("");
            return name;
        }
    }
    name="empty";
    return name;
}