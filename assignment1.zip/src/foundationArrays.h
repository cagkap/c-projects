//
// Created by Cagla on 12/11/2020.
//

#ifndef ASSIGNMENT1_FOUNDATIONARRAYS_H
#define ASSIGNMENT1_FOUNDATIONARRAYS_H

#endif //ASSIGNMENT1_FOUNDATIONARRAYS_H
#include <iostream>
#include <string>
#include <fstream>
#pragma once
using namespace std;
#include "Card.h"
class foundationArrays{
public:
    array<Card,13> hearts;
    array<Card,13> diamonds;
    array<Card,13> spades;
    array<Card,13> clubs;
    foundationArrays();
    void putCard(array<Card,13> &array,string name);
    bool getInfo(string name);
    char* getLast( array<Card,13> array);
    void printFoundation(array<Card,13>,ofstream &outputText);
    string getFromFoundation(char i);
    string getCard(array<Card,13> &array);

};