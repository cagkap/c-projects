//
// Created by Cagla on 12/11/2020.
//

#ifndef ASSIGNMENT1_WASTEARRAY_H
#define ASSIGNMENT1_WASTEARRAY_H

#endif //ASSIGNMENT1_WASTEARRAY_H
#include <iostream>
#include <string>
#include <fstream>
#pragma once
using namespace std;
#include "Card.h"
class wasteArray{
public:
    /*array<Card,8> waste1;
    array<Card,8> waste2;
    */array<Card,8> waste3;
    array<Card,3> waste;
    array<Card,24> previousCards;
    void putWaste(array<Card, 3> tempArray);
    array<string,2> getFromWaste();
    array<Card,24> getAll();
    void putOne(string cardName);
    void printWaste(ofstream &outputText);
};