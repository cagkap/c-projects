//
// Created by Cagla on 08/11/2020.
//

#ifndef ASSIGNMENT1_PILEARRAYS_H
#define ASSIGNMENT1_PILEARRAYS_H

#endif //ASSIGNMENT1_PILEARRAYS_H
#include <iostream>
#include <string>
#include <fstream>
#pragma once
using namespace std;
#include "Card.h"

class pileArrays{
public:
    array<Card,25> array1;
    array<Card,25> array2;
    array<Card,25> array3;
    array<Card,25> array4;
    array<Card,25> array5;
    array<Card,25> array6;
    array<Card,25> array7;
    pileArrays(array<Card, 52> &deckArray);
    bool setCondOpen(array<Card,25> &array);
    bool openCard(char i);
    string getCard(char i);
    string choosePileandGetCard(array<Card,25> &array);
    bool choosePile(char i,string name,bool,ofstream &outputText);
    bool putCard(array<Card,25> &array,string name,bool,ofstream &outputText);
    void printPile(ofstream &outputText);
    void printPile2(array<Card,25>,int i,ofstream &outputText);
    bool checkPile(char);
    bool checkPile2(array<Card,25> &array);
    bool checkPile3(array<Card,25> &array);
    bool checkPile4(char i);

};