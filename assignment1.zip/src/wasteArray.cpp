//
// Created by Cagla on 12/11/2020.
//
#include <iostream>
#include <string>
#include <fstream>
#include <array>
using namespace std;
#include "Card.h"
#include "wasteArray.h"

void wasteArray::putWaste(array<Card, 3> tempArray) {
    if(waste[0].getName() == ""&&waste[1].getName() == ""&&waste[2].getName() == ""){
        waste[0]=tempArray[0];
        waste[1]=tempArray[1];
        waste[2]=tempArray[2];
        return;
    }else{
        int j=0;
        for(int i=0;i<=23;i++){
            if(previousCards[i].getName()==""){
                previousCards[i]=waste[j];
                if(j==2) {
                    break;
                }
                j++;


            }
        }
        waste[0]=tempArray[0];
        waste[1]=tempArray[1];
        waste[2]=tempArray[2];
        return;
    }
}
array<string,2> wasteArray::getFromWaste() {
    array<string, 2> info;
    string name;

    for (int i = 2; i >= 0; i--) {
        if (waste[i].getName() != "") {
            info[0] = waste[i].getName();
            waste[i].setName("");
            if (i == 0) {
                for (int j = 23; j >= 0; j--) {
                    if (previousCards[j].getName() != "") {
                        waste[0].setName(previousCards[j].getName()) ;
                        previousCards[j].setName("");
                        break;
                    }
                }
            }
            break;
        }
    }
        return info;
    }

array<Card,24> wasteArray::getAll() {

    for (int i = 0; i <= 2; i++) {
        if (waste[i].getName() != "") {
            for (int j = 0; j <= 23; j++) {
                if (previousCards[j].getName() == "") {
                    previousCards[j].setName(waste[i].getName());
                    waste[i].setName("");
                }
            }

        }

    }
    return previousCards;
}
    void wasteArray::putOne(string cardName) {

        for (int i = 0; i <=2; i++) {
            if (waste[i].getName() == "") {
                waste[i].setName(cardName);
                break;
            }
        }
    }

void wasteArray:: printWaste(ofstream &outputText) {

    if(waste[0].getName()==""){
        outputText<<"___ ";
    }else {
        outputText << waste[0].getName()<<" ";
    }
        if(waste[1].getName()==""){
            outputText<<"___ ";
        }else{
            outputText<<waste[1].getName()<<" ";
        }
    if(waste[2].getName()==""){
        outputText<<"___ ";
    }else{
        outputText<<waste[2].getName()<<" ";
    }
    }

