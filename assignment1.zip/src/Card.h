//
// Created by Cagla on 08/11/2020.
//
#include <iostream>
#include <string>
#include <fstream>
#pragma once
using namespace std;


class Card{
private:
    string name;
    string condition;
public:
    string getName();
    string setName(string name);
    string setCondition(string condition);
    string getCondition();
};