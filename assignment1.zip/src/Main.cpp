#include <iostream>

#include <fstream>
#include <array>
using namespace std;
#include "pileArrays.h"
#include "stockArray.h"
#include "wasteArray.h"
#include "foundationArrays.h"
#include <bits/stdc++.h>
int main(int argc, char** argv) {
   string myText;
   string myText2;
   int i=0;
   array<Card,52> deckArray;
   ifstream readDeck (argv[1]);
   ifstream readCommands (argv[2]);
   ofstream outputText(argv[3]);
   while (getline(readDeck, myText)) {
           Card card;
           card.setName(myText);
           deckArray[i]=card;
           i++;
   }
    pileArrays pileArray(deckArray);
    stockArray stockArray(deckArray);
    wasteArray wasteArray;
    foundationArrays foundationArrays;
    if(stockArray.stockArr[0].getName()!=""){
        outputText<< "@@@ ";

    }else{
        outputText<<"___ ";
    }
    wasteArray.printWaste(outputText);
    outputText<<"        ";
    foundationArrays.printFoundation(foundationArrays.hearts,outputText);
    foundationArrays.printFoundation(foundationArrays.diamonds,outputText);
    foundationArrays.printFoundation(foundationArrays.spades,outputText);
    foundationArrays.printFoundation(foundationArrays.clubs,outputText);
    outputText<<endl;
    outputText<<endl;
    pileArray.printPile(outputText);
    while(getline(readCommands,myText2)){
        outputText<< myText2 << endl;
        outputText <<endl;
        int n = myText2.length();
        char command[n];
        strcpy(command, myText2.c_str());
        if(command[5] == 'f' && command[6]=='r'){
            array<Card,3> tempArray=stockArray.getFromStock();
            if(tempArray[0].getName()=="empty stock"){
                array<Card,24> tempArr= wasteArray.getAll();
                stockArray.putAll(tempArr);
                for (int j = 0; j <= 23; j++) {
                    wasteArray.previousCards[j].setName("");
                }
            }else {
                wasteArray.putWaste(tempArray);
            }
        }
        else if(command[0]='o'&&command[1]=='p'){//open _
            bool check= pileArray.checkPile4(command[5]);
            if (check==true) {
                bool move = pileArray.openCard(command[5]);
                if (move == false) {
                    outputText << "Invalid Move!" << endl;
                    outputText<<endl;
                }
            }else{
                outputText << "Invalid Move!" << endl;
                outputText<<endl;

            }
        }else if(command[19]=='p'){//move to foundation pile _
            bool check= pileArray.checkPile(command[24]);
            if(check==true) {
                string name = pileArray.getCard(command[24]);
                bool value = foundationArrays.getInfo(name);
                if (value == false) {
                    pileArray.choosePile(command[24], name, false,outputText);
                    outputText << "Invalid Move!" << endl;
                    outputText<<endl;

                }
            }else{
                outputText << "Invalid Move!" << endl;
                outputText<<endl;
                ;
            }
        }else if(command[19]=='w'){//move to foundation waste
            if(wasteArray.waste[0].getName()==""){
                outputText << "Invalid Move!" << endl;
                outputText<<endl;
            }else {
                array<string, 2> info = wasteArray.getFromWaste();
                bool value = foundationArrays.getInfo(info[0]);
                if (value == false) {
                    wasteArray.putOne(info[0]);
                    outputText << "Invalid Move!" << endl;
                    outputText<<endl;
                }
            }
        }else if(command[1]=='o'&&command[5]=='p'){//move pile _ _ _
            bool check= pileArray.checkPile(command[10]);
            if(check==true) {
                int cardCount;
                int k;
                if(command[12]=='1'&&(command[13]=='0'||command[13]=='1'||command[13]=='2')){
                     cardCount=10+int(command[12]) - 48;
                    k=1;
                }else{
                     k=0;
                cardCount = int(command[12]) - 48 + 1;}
                string tempArray[cardCount];
                for (int i = 0; i < cardCount; i++) {
                    string name = pileArray.getCard(command[10]);
                    tempArray[i] = name;
                }
            for(int i=cardCount-1;i>=0;i--) {
                bool value = pileArray.choosePile(command[14+k], tempArray[i], true,outputText);
                if (value == false) {
                    for (int i = cardCount - 1; i >= 0; i--) {
                        pileArray.choosePile(command[10], tempArray[i], false,outputText);
                    }
                    outputText << "Invalid Move!" << endl;
                    outputText<<endl;
                    break;
                }
            }
                }else{
                outputText << "Invalid Move!" << endl;
                outputText<<endl;
            }
        }else if(command[2]=='v'&& command[5]=='w'){//move waste _
            if(wasteArray.waste[0].getName()==""){
                outputText << "Invalid Move!" << endl;
                outputText<<endl;
                }else {
                array<string, 2> info = wasteArray.getFromWaste();
                bool value = pileArray.choosePile(command[11], info[0], true,outputText);
                if (value == false) {
                    wasteArray.putOne(info[0]);
                    outputText << "Invalid Move!" << endl;
                    outputText<<endl;
                }
            }

        }else if(command[5]=='f'){
            string name=foundationArrays.getFromFoundation(command[16]);
            if(name=="empty"){
                outputText << "Invalid Move!" << endl;
                outputText<<endl;
            }else {
                bool value = pileArray.choosePile(command[18], name, true,outputText);
                if (value == false) {
                    foundationArrays.getInfo(name);
                    outputText << "Invalid Move!" << endl;
                    outputText<<endl;
                }
            }
        }else if(command[2]=='i'&&command[3]=='t'){//exit
            outputText <<"****************************************"<<endl;
            outputText<<endl;
            outputText<<"Game Over!";
            return 0;

        }

        outputText <<"****************************************"<<endl;
        outputText<<endl;
        if(stockArray.stockArr[0].getName()!=""){
            outputText<< "@@@ ";

        }else{
            outputText<<"___ ";
        }
        wasteArray.printWaste(outputText);
        outputText<<"        ";
        foundationArrays.printFoundation(foundationArrays.hearts,outputText);
        foundationArrays.printFoundation(foundationArrays.diamonds,outputText);
        foundationArrays.printFoundation(foundationArrays.spades,outputText);
        foundationArrays.printFoundation(foundationArrays.clubs,outputText);
        outputText<<endl;
        if(foundationArrays.hearts[12].getName()=="H13"&&foundationArrays.diamonds[12].getName()=="D13"&&foundationArrays.spades[12].getName()=="S13"&&foundationArrays.clubs[12].getName()=="C13") {
            outputText << endl;
            outputText << "You Win!" << endl;
            outputText << endl;
            outputText << "Game Over";

            return 0;
        }
	outputText<<endl;
        pileArray.printPile(outputText);

    }

    outputText.close();
    return 0;
}
