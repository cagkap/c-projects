//
// Created by Cagla on 08/11/2020.
//

#include <iostream>
#include <string>
#include <fstream>
#include "array"
using namespace std;
#include "pileArrays.h"
#include <bits/stdc++.h>

pileArrays::pileArrays(array<Card,52> &deckArray) {
    for(int i=51;i>=23;i--){
        deckArray[i].setCondition("close");

    }
        deckArray[51].setCondition("open");
        array1={deckArray[51]};
        deckArray[44].setCondition("open");
        array2={deckArray[50],deckArray[44]};
        deckArray[38].setCondition("open");
       array3={deckArray[49],deckArray[43],deckArray[38]};
        deckArray[33].setCondition("open");
       array4={deckArray[48],deckArray[42],deckArray[37],deckArray[33]};
        deckArray[29].setCondition("open");
         array5={deckArray[47],deckArray[41],deckArray[36],deckArray[32],deckArray[29]};
        deckArray[26].setCondition("open");
        array6={deckArray[46],deckArray[40],deckArray[35],deckArray[31],deckArray[28],deckArray[26]};
        deckArray[24].setCondition("open");
        array7={deckArray[45],deckArray[39],deckArray[34],deckArray[30],deckArray[27],deckArray[25],deckArray[24]};
        };

bool pileArrays::openCard(char i) {
    if(i=='0'){
        return setCondOpen(array1);

    }else if(i=='1'){
        return setCondOpen(array2);
    }else if(i=='2'){
        return setCondOpen(array3);
    }else if(i=='3'){
        return setCondOpen(array4);
    }else if(i=='4'){
        return setCondOpen(array5);
    }else if(i=='5'){
        return setCondOpen(array6);
    }else if(i=='6'){
        return setCondOpen(array7);
    }

}
bool pileArrays::setCondOpen(array<Card, 25> &array) {
    for (int j = 6; j>=0; j--) {
        if (array[j].getCondition() != ""&&array[j].getCondition()!="open") {
            array[j].setCondition("open");
            return true;
        }else if(array[j].getCondition() != ""&&array[j].getCondition()!="open"){
            return false;

        }else if(array[j].getCondition()=="open"){
            return false;
        }
    }
}
string pileArrays::getCard(char i)  {
    if(i=='0'){
        return choosePileandGetCard(array1);
    }else if(i=='1'){
        return choosePileandGetCard(array2);
    }else if(i=='2'){
        return choosePileandGetCard(array3);
    }else if(i=='3'){
        return choosePileandGetCard(array4);
    }else if(i=='4'){
        return choosePileandGetCard(array5);
    }else if(i=='5'){
        return choosePileandGetCard(array6);
    }else if(i=='6'){
       return choosePileandGetCard(array7);
    }

}
string pileArrays::choosePileandGetCard(array<Card, 25> &array)   {
    string name;
    for (int j = 24; j>=0; j--){
        if(array[j].getName()!=""){
            name=array[j].getName();
            array[j].setName("");
            array[j].setCondition("");
            break;
        }

    }
    return name;
}
bool pileArrays::choosePile(char i,string name,bool value,ofstream &outputText) {
    if(i=='0'){
        return putCard(array1,name,value,outputText);
    }else if(i=='1'){
        return putCard(array2,name,value,outputText);
    }else if(i=='2'){
        return putCard(array3,name,value,outputText);
    }else if(i=='3'){
        return putCard(array4,name,value,outputText);
    }else if(i=='4'){
        return putCard(array5,name,value,outputText);
    }else if(i=='5'){
        return putCard(array6,name,value,outputText);
    }else if(i=='6'){
        return putCard(array7,name,value,outputText);
    }

}
bool pileArrays::putCard(array<Card, 25> &array,string name,bool value,ofstream &outputText) {
    int n = name.length();
    char name2[n + 1];
    strcpy(name2, name.c_str());
    if (array[0].getName() == "") {
        if(name[1]=='1'&&name[2]=='3') {
            array[0].setName(name);
            array[0].setCondition("open");
            return true;
        }else{
            return false;
        }
    }
    for (int j = 24; j >= 0; j--) {
        if (array[j].getName() != "") {
            int p = array[j].getName().length();
            char arrayName[p + 1];
            strcpy(arrayName, array[j].getName().c_str());
            int i = int(name2[2]) - 48;
            int k = int(arrayName[2]) - 48;
            if (((name2[1] == '0' && arrayName[1] == '0' && i + 1 == k) || (name2[2] == '9' && arrayName[1] == '1')||(name2[1]=='1'&&arrayName[1]=='1'&&i+1==k))) {
                array[j + 1].setName(name);
                return true;
            } else if (value == false) {
                array[j + 1].setName(name);
                return true;
            } else {
                return false;
            }
        }
    }

}

void pileArrays::printPile(ofstream &outputText){
        for (int i = 0; i <=24; i++) {
           printPile2(array1,i,outputText);
            printPile2(array2,i,outputText);
            printPile2(array3,i,outputText);
            printPile2(array4,i,outputText);
            printPile2(array5,i,outputText);
            printPile2(array6,i,outputText);
            printPile2(array7,i,outputText);
            outputText<<endl;

        }
}
void pileArrays::printPile2(array<Card, 25> array,int i,ofstream &outputText) {
    if (array[i].getName() != ""&&(array[i].getCondition()=="open"||array[i].getCondition()=="")) {
        outputText << array[i].getName()<<"   ";

    }else if(array[i].getCondition()=="close"){
        outputText<<"@@@   ";

    }else{
        outputText<<"      ";

    }


}
bool pileArrays::checkPile(char i) {
    if(i=='0'){
        return checkPile2(array1);
    }else if(i=='1'){
        return checkPile2(array2);
    }else if(i=='2'){
        return checkPile2(array3);
    }else if(i=='3'){
        return checkPile2(array4);
    }else if(i=='4'){
        return checkPile2(array5);
    }else if(i=='5'){
        return checkPile2(array6);
    }else if(i=='6'){
        return checkPile2(array7);
    }
}
bool pileArrays::checkPile2(array<Card,25> &array) {
    if (array[0].getName() == "") {
        return false;
    }
    for(int i=24;i>=0;i--) {
        if (array[i].getName() != "") {
            if (array[i].getCondition() == "close") {
                return false;
            } else {
                return true;
            }
        }
    }
}
bool pileArrays::checkPile3(array<Card,25> &array) {
    if (array[0].getName() == "") {
        return false;
    }else {
        return true;
    }
}
bool pileArrays::checkPile4(char i){
    if(i=='0'){
        return checkPile3(array1);
    }else if(i=='1'){
        return checkPile3(array2);
    }else if(i=='2'){
        return checkPile3(array3);
    }else if(i=='3'){
        return checkPile3(array4);
    }else if(i=='4'){
        return checkPile3(array5);
    }else if(i=='5'){
        return checkPile3(array6);
    }else if(i=='6'){
        return checkPile3(array7);
    }
}