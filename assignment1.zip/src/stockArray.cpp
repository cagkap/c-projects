//
// Created by Cagla on 12/11/2020.
//
#include <iostream>
#include <string>
#include <fstream>
#include <array>
using namespace std;
#include "stockArray.h"


stockArray::stockArray(array<Card,52> &deckArray) {
    stockArr.swap(reinterpret_cast<array<Card, 24> &>(deckArray));

}

std::array<Card, 3> stockArray::getFromStock() {
    array<Card,3> tempArr;
    int j=0;
    if(stockArr[0].getName()==""){
        tempArr[0].setName("empty stock");
    }
    for(int i=23;i>=0;i--){
        if(stockArr[i].getName()!="") {
            tempArr[j] = stockArr[i];
            stockArr[i].setName("");
            if(j==2){
                break;
            }
            j++;
        }

    }
    return tempArr;
}
void stockArray::putAll(array<Card,24> tempArr) {
    int j=0;
    for(int i=23;i>=0;i--) {
        if (tempArr[i].getName() != "") {
            stockArr[j].setName(tempArr[i].getName());
            j++;
        }
    }
}