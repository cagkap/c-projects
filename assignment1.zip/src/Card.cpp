//
// Created by Cagla on 08/11/2020.
//
#include <iostream>
#include <string>
#include <fstream>
using namespace std;
#include "Card.h"

string Card::getName() {
    return name;
}
string Card::setName(string name) {
    this->name=name;
    return "";
}
string Card::setCondition(string condition) {
    this->condition=condition;
    return "";
}
string Card::getCondition() {
    return condition;
}