//
// Created by Cagla on 12/11/2020.
//

#ifndef ASSIGNMENT1_STOCKARRAY_H
#define ASSIGNMENT1_STOCKARRAY_H

#endif //ASSIGNMENT1_STOCKARRAY_H
#include "Card.h"
#pragma once
class stockArray{
public:
    array<Card,24> stockArr;
    stockArray(array<Card,52> &deckArray);
    std::array<Card, 3> getFromStock();
    void putAll(array<Card,24> tempArr);

};