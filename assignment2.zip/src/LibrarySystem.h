//
// Created by Cagla on 21/11/2020.
//

#ifndef MATRIX_LIBRARYSYSTEM_H
#define MATRIX_LIBRARYSYSTEM_H

#endif //MATRIX_LIBRARYSYSTEM_H
using namespace std;
#include "string"
#include <iostream>
#include <fstream>
#include "UserList.h"



class LibrarySystem{
public:
    UserList userList;
    movieList notCheckedMovies;
    ofstream outputText;
    int p=0;
    LibrarySystem();
    LibrarySystem(char**);
    ~LibrarySystem();
    void addMovie(const int movieId,const string movieTitle,const int year);
    void deleteMovie(const int Id);

    void addUser(const int userId,const string userName);
    void deleteUser(const int userId);

    void checkoutMovie(const int movieId,const int userId);
    void returnMovie(const int movieId);

    void showAllMovies();
    void showMovie(const int movieId);
    void showUser(const int userId);

};