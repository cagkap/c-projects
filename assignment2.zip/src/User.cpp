//
// Created by Cagla on 20/11/2020.
//
#include "User.h"
User::User(int Id,string name,movieList userMovies) {
    this->ID=Id;
    this->name=name;
    this->userMovies=userMovies;

}
User::User() {}