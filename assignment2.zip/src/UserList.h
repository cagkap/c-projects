//
// Created by Cagla on 22/11/2020.
//

#ifndef MATRIX_USERLIST_H
#define MATRIX_USERLIST_H

#endif //MATRIX_USERLIST_H

#include <array>
#include "User.h"

class UserList{
    struct Node{
        Node(User user);

        User user;
        Node* nextUser;
        Node* prevUser;
    };
public:
    Node *head= nullptr;
    void Insert(User user);
    void Delete(int id);
    bool checkUser(int i);
    array<int,2> checkUsersMovie(int id);
    void addMovieToUser(int movieId,int userId,Movie movie);
    void deleteMovieFromUser(int movieID,int userID);
    void printMovies(ofstream &outputText);
    void showMovie(int id,ofstream &outputText);
    User getUser(int);
};