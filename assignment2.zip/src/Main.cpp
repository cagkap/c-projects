#include <iostream>
#include <fstream>
#include <sstream>
#include "LibrarySystem.h"
#include <stack>
using namespace std;

int main(int argc, char** argv) {
    string command;
    std::ifstream readCommands(argv[1]);

    LibrarySystem librarySystem(argv);
    //Read commands from input file
    while(getline(readCommands,command)) {
        istringstream ss(command);
        string substr;
        string temp[4];
        int i =0;
        while (getline(ss, substr, '\t')) {
            temp[i]=substr;
            i++;
        }
        if(temp[0]=="addMovie") {
            int j = stoi(temp[1]);
            int p = stoi(temp[3]);
            librarySystem.addMovie(j, temp[2], p);

        }else if(temp[0]=="addUser"){
            int j = stoi(temp[1]);
            librarySystem.addUser(j,temp[2]);

        }else if(temp[0]=="checkoutMovie"){
            int j = stoi(temp[1]);
            int p = stoi(temp[2]);
            librarySystem.checkoutMovie(j,p);

        }else if(temp[0]=="deleteMovie"){
            int j = stoi(temp[1]);
            librarySystem.deleteMovie(j);

        }else if(temp[0]=="deleteUser"){
            int j = stoi(temp[1]);
            librarySystem.deleteUser(j);

        }else if(temp[0]=="returnMovie"){
            int j = stoi(temp[1]);
            librarySystem.returnMovie(j);

        }else if(temp[0]=="showAllMovie"){
            librarySystem.showAllMovies();

        }else if(temp[0]=="showMovie"){
            int j = stoi(temp[1]);
            librarySystem.showMovie(j);

        }else if(temp[0]=="showUser"){
            int j = stoi(temp[1]);
            librarySystem.showUser(j);
        }
    }
    }

