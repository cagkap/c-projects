//
// Created by Cagla on 21/11/2020.
//

#include "LibrarySystem.h"
LibrarySystem::LibrarySystem() {

}
LibrarySystem::LibrarySystem(char** argv) {
    outputText.open(argv[2]);
    outputText<<"===Movie Library System===";
    outputText<<endl;
}

void LibrarySystem::addMovie(const int movieId, const string movieTitle, const int year) {
    if(p!=1) {
        outputText<<endl;
        outputText << "===addMovie() method test===" << endl;
        p = 1;
    }
    //check if movie exists
    if(notCheckedMovies.checkMovie(movieId) && userList.checkUsersMovie(movieId)[0] == 1){
        Movie movie(movieId,movieTitle,year);
        notCheckedMovies.insertMovie(movie);
        outputText<<"Movie "<<movieId<<" has been added"<<endl;
    }
    else{
        outputText<<"Movie "<<movieId<<" already exists"<<endl;
    }

}
void LibrarySystem::deleteMovie(const int Id) {

    if(p!=2){
        outputText<<endl;
        outputText<<"===deleteMovie() method test==="<<endl;
        p=2;
    }
    array<int,2> arr;//if arr[0] is 0 movie exists in user's movies
    //check if userlist is empty
    if(userList.head== nullptr){
        arr={1,0};
    }else{
    arr=userList.checkUsersMovie(Id);
    }
    //if movie exists in notChecked movies delete it
    if(!notCheckedMovies.checkMovie(Id)) {
        notCheckedMovies.deleteMovie(Id);
        outputText<< "Movie " << Id << " has not been checked out" << endl;
        outputText << "Movie " << Id << " has been deleted" << endl;
        return;

    }else if(arr[0]==0){
        //delete movie from user's movies
        userList.deleteMovieFromUser(Id,arr[1]);
        outputText<<"Movie "<<Id<<" has been checked out"<<endl;
        outputText << "Movie " << Id << " has been deleted" << endl;
        return;
    }else {
        outputText<<  "Movie " << Id << " does not exist" << endl;

    }
}
void LibrarySystem::addUser(const int userId, const string userName) {
    if(p!=3) {
        outputText<<endl;
        outputText << "===addUser() method test===" << endl;
        p = 3;
    }
    if(userList.checkUser(userId)){//if user does not exist
        movieList userMovies;
        User user(userId,userName,userMovies);
        userList.Insert(user);
        outputText<<"User "<<userId<<" has been added"<<endl;
    }else{
        outputText<<"User "<<userId<<" already exists"<<endl;
    }
}
void LibrarySystem::checkoutMovie(const int movieId, const int userId) {
    if(p!=4) {
        outputText<<endl;
        outputText << "===checkoutMovie() method test===" << endl;
        p = 4;
    }
    if (notCheckedMovies.checkMovie(movieId) && userList.checkUsersMovie(movieId)[0] == 1) {//if movie does not exist
        outputText << "Movie " << movieId << " does not exist for checkout" << endl;
        return;
    }
    if (userList.checkUser(userId)) {//if user does not exist
        outputText << "User " << userId << " does not exist for checkout" << endl;
        return;
    }
    array<int, 2> arr = userList.checkUsersMovie(movieId);
    if (arr[0] == 0) {//if film already checked out
        outputText << "Movie " << movieId << " does not exist for checkout"<< endl;
    } else {//check out movie
        Movie movie = notCheckedMovies.getMovie(movieId);
        notCheckedMovies.deleteMovie(movieId);
        userList.addMovieToUser(movieId, userId, movie);
        outputText<<"Movie "<<movieId<<" has been checked out by User "<<userId<<endl;

    }
}
void LibrarySystem::deleteUser(const int userId) {
    if(p!=5) {
        outputText<<endl;
        outputText << "===deleteUser() method test===" << endl;
        p = 5;
    }
    if(userList.checkUser(userId)){//check ıf user exists
        outputText<<"User "<<userId<<" does not exist"<<endl;
        return;
    }else{
        userList.Delete(userId);
        outputText<<"User "<<userId<< " has been deleted"<<endl;
    }
}
void LibrarySystem::returnMovie(const int movieId) {
    if(p!=6) {
        outputText<<endl;
        outputText << "===returnMovie() method test===" << endl;
        p = 6;
    }
    if(notCheckedMovies.checkMovie(movieId) && userList.checkUsersMovie(movieId)[0] == 1){
        outputText<<"Movie "<<movieId<<" does not exist in the library"<<endl;
    }else if(!notCheckedMovies.checkMovie(movieId) && userList.checkUsersMovie(movieId)[0] == 1){
        outputText<<"Movie "<< movieId<<" has not been checked out"<<endl;
    }else if(userList.checkUsersMovie(movieId)[0]==0){//if movie is checked out, return it
        int userId= userList.checkUsersMovie(movieId)[1];
        User user=userList.getUser(userId);
        Movie movie=user.userMovies.getMovie(movieId);
        userList.deleteMovieFromUser(movieId,userId);
        notCheckedMovies.insertMovie(movie);
        outputText<<"Movie "<<movieId<<" has been returned"<<endl;
    }
}
void LibrarySystem::showAllMovies() {
    if(p!=7) {
        outputText<<endl;
        outputText << "===showAllMovie() method test===" << endl;
        p = 7;
    }
    outputText<<"Movie id - Movie name - Year - Status"<<endl;
    userList.printMovies(outputText);
    notCheckedMovies.printNotMovies(outputText);
}
void LibrarySystem::showMovie(const int movieId) {
    if(p!=8) {
        outputText<<endl;
        outputText << "===showMovie() method test===" << endl;
        p = 8;
    }
    if(notCheckedMovies.checkMovie(movieId) && userList.checkUsersMovie(movieId)[0] == 1){
        outputText<<"Movie with the id "<<movieId<<" does not exist"<<endl;
    }else if(!notCheckedMovies.checkMovie(movieId) && userList.checkUsersMovie(movieId)[0] == 1){
            Movie movie=notCheckedMovies.getMovie(movieId);
            outputText<<movie.id<<" "<<movie.title<<" "<<movie.year<<" Not checked out"<<endl;

    }else if(userList.checkUsersMovie(movieId)[0]==0){
        userList.showMovie(movieId,outputText);
    }
}
void LibrarySystem::showUser(const int userId) {
    if(p!=9) {
        outputText<<endl;
        outputText << "===showUser() method test===" << endl;
        p = 9;
    }
    if(userList.checkUser(userId)){//check if user exists
        outputText<<"User "<<userId<<" does not exist"<<endl;

    }else{
        User user=userList.getUser(userId);
        outputText<<"User id: "<<userId<<" User name: "<<user.name<<endl;
        outputText<<"User "<<userId<<" checked out the following Movies:"<<endl;
        if(user.userMovies.head!= nullptr){
            outputText<<"Movie id - Movie name - Year"<<endl;
            user.userMovies.printMovies(outputText);
        }
    }
}
LibrarySystem::~LibrarySystem() {

}