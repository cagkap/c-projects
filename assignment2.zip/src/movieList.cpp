//
// Created by Cagla on 21/11/2020.
//
#include "movieList.h"
#include <sstream>
#include <fstream>
#include "string"
void movieList::insertMovie(Movie movie) {
    Node *newNode= new Node(Movie(movie.id,movie.title,movie.year));
    newNode->movie=movie;
    newNode->nextMovie= nullptr;
    if(head!= nullptr){
        Node *temp=head;
        while(temp->nextMovie!=head) {//till last node
            temp = temp->nextMovie;
        }
        temp->nextMovie=newNode;
        newNode->nextMovie=head;
    }else{
        head=newNode;
        newNode->nextMovie=head;
    }
}
void movieList::deleteMovie(int i) {
    Node *temp=head;
    if(head->movie.id==i&&head->nextMovie==head){//if first element is to be deleted and there is one element
        delete head;
        head= nullptr;
        return;
    }
    if(head->movie.id==i){//if first element is to be deleted
        while(temp->nextMovie!=head){
            temp=temp->nextMovie;
        }
        temp->nextMovie=head->nextMovie;
        head=temp->nextMovie;
        return;
    }

    while(temp->nextMovie!=head){
        if(temp->nextMovie->movie.id==i){
            temp->nextMovie=temp->nextMovie->nextMovie;
            return;
        }
        temp=temp->nextMovie;
    }
}
bool movieList::checkMovie(int i) {
    if(head== nullptr){
        return true;
    }
    if(head->movie.id==i){
        return false;
    }
    Node *temp=head;
    while(temp->nextMovie!=head){
        temp=temp->nextMovie;
        if(temp->movie.id==i){
            return false;
        }
    }
    return true;
}
Movie movieList::getMovie(int ID) {
    if(head->movie.id==ID){
        return head->movie;
    }
    Node *temp=head;
    while(temp->nextMovie!=head){
        temp=temp->nextMovie;
        if(temp->movie.id==ID){
            return temp->movie;
        }
    }
}
void movieList::printNotMovies(ofstream &outputText) {
    if(head== nullptr){
        return;
    }
    outputText<<head->movie.id<<" "<<head->movie.title<<" "<<head->movie.year<<" "<<"Not checked out"<<endl;
    Node *temp=head;
    while(temp->nextMovie!=head){
        temp=temp->nextMovie;
        outputText<<temp->movie.id<<" "<<temp->movie.title<<" "<<temp->movie.year<<" "<<"Not checked out"<<endl;
        }
}
void movieList::printChecked(int userId,ofstream &outputText) {
    if(head== nullptr){
        return;
    }
    outputText<<head->movie.id<<" "<<head->movie.title<<" "<<head->movie.year<<" "<<"Checked out by User "<<userId<<endl;
    Node *temp=head;
    while(temp->nextMovie!=head){
        temp=temp->nextMovie;
        outputText<<temp->movie.id<<" "<<temp->movie.title<<" "<<temp->movie.year<<" "<<"Checked out by User "<<userId<<endl;
    }
}
void movieList::printMovies(ofstream &outputText) {
    outputText<< head->movie.id<<" "<<head->movie.title << " "<< head->movie.year<<endl;
    Node *temp=head;
    while(temp->nextMovie!=head){
        temp=temp->nextMovie;
        outputText<<temp->movie.id<<" "<<temp->movie.title<<" "<<temp->movie.year<<endl;
    }

}