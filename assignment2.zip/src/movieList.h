//
// Created by Cagla on 21/11/2020.
//

#ifndef MATRIX_MOVIELIST_H
#define MATRIX_MOVIELIST_H

#endif //MATRIX_MOVIELIST_H
#include "Movie.h"
class movieList{
    struct Node{

        Node(Movie movie) : movie(movie) {
        }
        Movie movie;
        Node *nextMovie;
    };

public:
    Node *head= nullptr;
    void insertMovie(Movie);
    void deleteMovie(int i);
    bool checkMovie(int i);
    Movie getMovie(int ID);
    void printNotMovies(ofstream &outputText);
    void printChecked(int userID,ofstream &outputText);
    void printMovies(ofstream &outputText);

};