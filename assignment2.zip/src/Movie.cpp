//
// Created by Cagla on 20/11/2020.
#include "Movie.h"
Movie::Movie(int id,string title,int year) {
    this->id=id;
    this->title=title;
    this->year=year;

}
