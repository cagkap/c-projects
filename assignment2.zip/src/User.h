//
// Created by Cagla on 20/11/2020.
//

#ifndef MATRIX_USER_H
#define MATRIX_USER_H

#endif //MATRIX_USER_H
#include "movieList.h"
class User{
public:
    int ID;
    string name;
    movieList userMovies;
    User(int Id,string name,movieList);
    User();
};