//
// Created by Cagla on 20/11/2020.
//
using namespace std;
#include <iostream>
#ifndef MATRIX_MOVIE_H
#define MATRIX_MOVIE_H

#endif //MATRIX_MOVIE_H
class Movie{
public:
    int id;
    string title;
    int year;
    Movie(int id,string title,int year);
};