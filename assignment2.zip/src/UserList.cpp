//
// Created by Cagla on 22/11/2020.
//

#include "UserList.h"
using namespace std;
#include "string"
#include <iostream>
#include <fstream>

void UserList::Insert(User user) {
    Node* newUser= new Node(User());
    newUser->user=user;
    if(head== nullptr){//list is empty
        newUser->nextUser=newUser->prevUser=newUser;
        head=newUser;
        return;
    }
    Node *lastUser=head->prevUser;
    lastUser->nextUser=newUser;
    newUser->prevUser=lastUser;
    newUser->nextUser=head;
    head->prevUser=newUser;

}
void UserList::Delete(int id) {//önce listenin boşluğunu kontrol et
    Node *temp=head;
    if(temp->user.ID==id){
        temp->prevUser->nextUser=temp->nextUser;
        temp->nextUser->prevUser=temp->prevUser;
        head=temp->nextUser;
        return;
    }
    while(temp->user.ID!=id){
        temp=temp->nextUser;
    }
    temp->prevUser->nextUser=temp->nextUser;
    temp->nextUser->prevUser=temp->prevUser;

}
bool UserList::checkUser(int id) {
    if(head== nullptr){
        return true;
    }
    if(head->user.ID==id){
        return false;
    }
    Node *temp=head;
    while(temp->nextUser != head){
        temp=temp->nextUser;
        if(temp->user.ID==id){
            return false;
        }
    }
    return true;
}

UserList::Node::Node(User user) : user(user) {

}
array<int,2> UserList::checkUsersMovie(int id) {
    array<int,2> arr;
    if(head== nullptr){
        arr={1,0};
        return arr;

    }
    if(head->user.userMovies.checkMovie(id)==false){
         arr={0,head->user.ID};
        return arr;
    }
    Node *temp = head;
    while (temp->nextUser != head) {
        temp = temp->nextUser;
        bool value=temp->user.userMovies.checkMovie(id);
        if(value==false){
             arr={0,temp->user.ID};
            return arr;
        }
    }
    arr={1, 0};
    return arr;
}
void UserList::addMovieToUser(int movieId, int userId,Movie movie) {
    if (head->user.ID == userId) {
        head->user.userMovies.insertMovie(movie);
    } else {
        Node *temp = head;
        while (temp->nextUser != head) {
            temp = temp->nextUser;
            if (temp->user.ID == userId) {
                temp->user.userMovies.insertMovie(movie);
            }
        }
    }
}
void UserList::deleteMovieFromUser(int movieID,int userID) {
    if(head->user.ID==userID){
        head->user.userMovies.deleteMovie(movieID);
    }else{
        Node *temp=head;
        while (temp->nextUser != head) {
            temp = temp->nextUser;
            if (temp->user.ID == userID) {
                temp->user.userMovies.deleteMovie(movieID);
            }
        }
    }

}
void UserList::printMovies(ofstream &outputText) {
    if(head== nullptr){
        return;
    }
    head->user.userMovies.printChecked(head->user.ID,outputText);
    Node *temp=head;
    while(temp->nextUser != head){
        temp=temp->nextUser;
        temp->user.userMovies.printChecked(temp->user.ID,outputText);
    }
}
void UserList::showMovie(int id,ofstream &outputText) {
    if(head== nullptr){
        return;
    }
    if(head->user.userMovies.checkMovie(id)==false){
        Movie movie=head->user.userMovies.getMovie(id);
        outputText<<movie.id<<" "<<movie.title<<" "<<movie.year<<" Checked by User "<<head->user.ID<<endl;
        return;
    }
    Node *temp=head;
    while(temp->nextUser != head){
        temp=temp->nextUser;
        if(temp->user.userMovies.checkMovie(id)==false){
            Movie movie=temp->user.userMovies.getMovie(id);
            outputText<<movie.id<<" "<<movie.title<<" "<<movie.year<<" Checked out by User "<<temp->user.ID<<endl;
            return;
        }
    }
}
User UserList::getUser(int userID) {
    if(head->user.ID==userID){
        return head->user;
    }else{
        Node *temp=head;
        while (temp->nextUser != head) {
            temp = temp->nextUser;
            if (temp->user.ID == userID) {
                return temp->user;
            }
        }
    }
}